#include <iostream>
using namespace std;
int main() {
	int age;
	cin>>age;
	if (age<=17)
	cout<<"junior"<<endl;
	else if (age>=65)
	cout<<"senior"<<endl;
	else
	cout<<"adult"<<endl;
}
