#include <iostream>
using namespace std;
int main() {
	int m,n,i;
	cin>>m>>n;
	for(i=0;i<m;i++)
		cout<<"y";

	for(i=0;i<n;i++)
		cout<<"z";
cout<<endl;
}
