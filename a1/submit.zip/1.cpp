#include <iostream>
#include <string>
using namespace std;
int main() {
  string name;
  cin>>name;
  cout<<"Hi "<<name<<endl;

}
